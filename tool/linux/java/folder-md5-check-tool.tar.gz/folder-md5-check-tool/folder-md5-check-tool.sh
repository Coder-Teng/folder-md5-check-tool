./jre/bin/java -jar lib/folder-md5-check-tool-1.0.0.jar params.txt
