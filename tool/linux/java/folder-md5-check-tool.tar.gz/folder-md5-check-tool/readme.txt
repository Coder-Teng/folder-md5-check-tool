﻿一、修改配置文件：params.txt
1、扫描文件夹下文件并记录md5，修改如下：
	command=1
	standardMd5Path=standard-md5.txt
	folerPath=/opt/test
2、检查文件夹下文件的md5，修改如下：
	command=2
	standardMd5Path=standard-md5.txt
	folerPath=/opt/test

参数说明：
	command：1或者2 分别代表以上两种操作。
	standard-md5：记录标准MD5列表的文件路径。
	folerPath：要扫描或者检查的文件夹路径。
	
二、执行脚本。
    ./folder-md5-check-tool.sh
	如果文件无执行权限，执行 chmod +x folder-md5-check-tool.sh
